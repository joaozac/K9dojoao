/**
 * 
 */
/**
 * 
 */
module PPI2 {
	requires java.desktop;
	requires java.sql;
}