package Main;

import javax.swing.*;
import BCrypts.BCryptUtil;
import JDBC.ConnectionFactory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.Cursor;

public class CadastrarFuncionario extends JFrame {
    private JTextField txtUsername, txtNome;
    private JPasswordField txtSenha, txtConfSenha;
    private JComboBox<String> cmbPerfil, cmbBoxCargo;
    private JTextField txtTelefone;
    private JTextField txtEmail;
    private JTextField txtCpf;

    public CadastrarFuncionario() {
        setTitle("Cadastrar Funcionário");
        setBounds(100, 100, 849, 602);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        txtNome = new JTextField();
        txtNome.setBounds(101, 111, 253, 20);
        contentPane.add(txtNome);
       
        cmbBoxCargo = new JComboBox<>(new String[]{"Gerente", "Tosador", "Caixa", "Adestrador", "Admin"});
        cmbBoxCargo.setBounds(145, 362, 146, 22);
        contentPane.add(cmbBoxCargo);
        
        txtCpf = new JTextField();
        txtCpf.setBounds(499, 111, 253, 20);
        contentPane.add(txtCpf);
        
        txtTelefone = new JTextField();
        txtTelefone.setBounds(101, 195, 253, 20);
        contentPane.add(txtTelefone);
        
        txtEmail = new JTextField();
        txtEmail.setBounds(499, 195, 253, 20);
        contentPane.add(txtEmail);
        
        txtUsername = new JTextField();
        txtUsername.setBounds(499, 271, 253, 20);
        contentPane.add(txtUsername);
        txtSenha = new JPasswordField();
        txtSenha.setBounds(499, 363, 253, 20);
        contentPane.add(txtSenha);
        txtConfSenha = new JPasswordField();
        txtConfSenha.setBounds(101, 271, 253, 20);
        contentPane.add(txtConfSenha);

        

        JButton btnSave = new JButton("");
        btnSave.setContentAreaFilled(false);
        btnSave.setBorderPainted(false);
        btnSave.setBorder(null);
        btnSave.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnSave.setBounds(365, 438, 98, 49);
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    saveUser();
                    Admin admin = new Admin(); // Criando uma instância de ClasseA
                    admin.loadAllUsers(); // Chamando o método
                    txtNome.setText(null);
                    txtCpf.setText(null);
                    txtTelefone.setText(null);
                    txtEmail.setText(null);
                    cmbBoxCargo.setSelectedItem(null);
                    txtUsername.setText(null);
                    
                }
            }
        });
        contentPane.add(btnSave);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(CadastrarFuncionario.class.getResource("/img/fundoCadas.png")));
        lblNewLabel.setBounds(0, 0, 833, 563);
        contentPane.add(lblNewLabel);
    }
    
    // Conectar ao Banco de Dados
    private Connection conectarBanco() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/projetointegradorpetshop";
        String user = "root";
        String password = "";
        return DriverManager.getConnection(url, user, password);
    }

    private boolean validateFields() {
        if (txtNome.getText().isEmpty() || txtCpf.getText().isEmpty() || txtTelefone.getText().isEmpty() || txtEmail.getText().isEmpty() || cmbBoxCargo.getSelectedItem().toString().isEmpty() || txtUsername.getText().isEmpty()
            || new String(txtSenha.getPassword()).isEmpty() || 
            new String(txtConfSenha.getPassword()).isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos os campos devem ser preenchidos.");
            return false;
        }
        if (!new String(txtSenha.getPassword()).equals(new String(txtConfSenha.getPassword()))) {
            JOptionPane.showMessageDialog(this, "As senhas não conferem.");
            return false;
        }
        return true;
    }

    private void saveUser() {
        try (Connection conexao = ConnectionFactory.createConnection()) {
            String sql = "INSERT INTO funcionarios (nome, cpf, telefone, email, cargo, username, senha) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pst = conexao.prepareStatement(sql)) {
            	pst.setString(1, txtNome.getText());
                pst.setString(2, txtCpf.getText());
                pst.setString(3, txtTelefone.getText());
                pst.setString(4, txtEmail.getText());
                pst.setString(5, cmbBoxCargo.getSelectedItem().toString());
                pst.setString(6, txtUsername.getText());
                pst.setString(7, BCryptUtil.hashPassword(new String(txtSenha.getPassword())));
                

                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Funcionário cadastrado com sucesso!");
                new Admin();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar funcionário: " + e.getMessage());
        }
    }
    

}

