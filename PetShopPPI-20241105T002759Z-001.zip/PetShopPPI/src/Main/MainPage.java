 package Main;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import JDBC.ConnectionFactory;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Component;


public class MainPage extends JFrame {		
	public static int xMouse, yMouse;	
	private static final long serialVersionUID = 1L;		
	private JPanel contentPane;
	private JTextField  txtNomeCliente,txtCpfCliente,txtEnderecoCliente,txtTelefoneCliente,txtEmailCliente;
	private JTextField textAlergia,textCondicaoSaude,textRaca,textPorte,textPeso,textIdade, textNomeAnimal, txtFiltroAgen;
	private DefaultTableModel tableModelCliente, tableModelAnimal, tableModelAgendamento; //tableModel
	private JTable tableClientes, tableAgendamento, tableAnimais;
	private JTextField txtFiltroClientes, txtDataAgen, txtFiltroAnimal;
    private JComboBox<String> comboBoxClientes, comboBoxAnimais, comboBoxServico, comboBoxHora, comboBoxStatus, comboBoxValor, comboBoxAgendamentoFiltro;
    private JButton btnRefreshAnimal, btnRefreshClientes;
    private JTextField txtNomeClienteAgen;




	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainPage frame = new MainPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}	
	public MainPage() {		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1080, 720);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);		
		contentPane.setLayout(null);		
		setUndecorated(true); //Tirar os botões da barra de Tarefas				
		//-------------- Close Button --------------	--------------	--------------	
		JPanel panelBarra = new JPanel();
		panelBarra.setBounds(0, 0, 1080, 34);
		panelBarra.setLayout(null);
		panelBarra.setBackground(new Color(36, 121, 188));
		contentPane.add(panelBarra);		
		//-------------- Minimize Bar --------------	--------------	--------------			
		JLabel lblCloseWin = new JLabel("");
		lblCloseWin.setBounds(1043, 0, 27, 34);
		panelBarra.add(lblCloseWin);
		lblCloseWin.setBorder(null);
		lblCloseWin.setVerifyInputWhenFocusTarget(false);
		lblCloseWin.setFocusTraversalKeysEnabled(false);
		lblCloseWin.setRequestFocusEnabled(false);
		lblCloseWin.setInheritsPopupMenu(false);
		lblCloseWin.setFocusable(false);
		lblCloseWin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
				dispose();
			}		
		});	
		lblCloseWin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblCloseWin.setIcon(new ImageIcon(MainPage.class.getResource("/img/closes.png")));
		lblCloseWin.setToolTipText("");
		lblCloseWin.setHorizontalAlignment(SwingConstants.CENTER);
		lblCloseWin.setForeground(Color.WHITE);		
		//-------------- Move Bar --------------	--------------	--------------					
		JLabel lblMoveWin = new JLabel("");
		lblMoveWin.setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
		lblMoveWin.setBackground(new Color(36, 121, 188));
		lblMoveWin.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x, y;
				x = e.getXOnScreen();
				y = e.getYOnScreen();
				setLocation(x - xMouse, y - yMouse);
			}
		});		
		lblMoveWin.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				xMouse = e.getX();
				yMouse = e.getX();
			}
		});
		lblMoveWin.setBounds(0, 0, 990, 34);
		panelBarra.add(lblMoveWin);	
		//---------------- Panel -----------------------------------
		JPanel panelInterativo = new JPanel();
		panelInterativo.setBackground(new Color(211, 211, 211));
		panelInterativo.setBounds(203, 34, 877, 686);
		contentPane.add(panelInterativo);
		panelInterativo.setLayout(null);	
		JTabbedPane tabPane = new JTabbedPane(JTabbedPane.TOP);
		tabPane.setBounds(0, -33, 889, 731);
		panelInterativo.add(tabPane);	
		JPanel panelMenuPrincipal = new JPanel();
		tabPane.addTab("New tab", null, panelMenuPrincipal, null);
		panelMenuPrincipal.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(MainPage.class.getResource("/img/z2z2.png")));
		lblNewLabel.setBounds(0, 11, 874, 681);
		panelMenuPrincipal.add(lblNewLabel);
		JPanel panelIDEIAS = new JPanel();
		tabPane.addTab("New tab", null, panelIDEIAS, null);
		panelIDEIAS.setLayout(null);				
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon(MainPage.class.getResource("/img/working-removebg-preview.png")));
		lblNewLabel_7.setBounds(122, 190, 663, 439);
		panelIDEIAS.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Em Desenvolvimento");
		lblNewLabel_8.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setBounds(135, 81, 560, 98);
		panelIDEIAS.add(lblNewLabel_8);
		//------------------- Clientes Cadastro ------------------------
		JPanel panelClientes = new JPanel();
		tabPane.addTab("New tab", null, panelClientes, null);
		panelClientes.setLayout(null);
		txtNomeCliente = new JTextField();
		txtNomeCliente.setBounds(68, 231, 250, 25);
		panelClientes.add(txtNomeCliente);		
		txtCpfCliente = new JTextField();
		txtCpfCliente.setBounds(471, 231, 250, 25);
		panelClientes.add(txtCpfCliente);
		txtEnderecoCliente = new JTextField();
		txtEnderecoCliente.setBounds(68, 378, 250, 25);
		panelClientes.add(txtEnderecoCliente);	
		txtTelefoneCliente = new JTextField();
		txtTelefoneCliente.setBounds(471, 378, 250, 25);
		panelClientes.add(txtTelefoneCliente);
		txtEmailCliente = new JTextField();
		txtEmailCliente.setBounds(68, 538, 250, 25);
		panelClientes.add(txtEmailCliente);	
		JButton btnSalvar = new JButton("");
		btnSalvar.setContentAreaFilled(false);
		btnSalvar.setBorderPainted(false);
		btnSalvar.setSelected(true);
		btnSalvar.setBorder(null);
		btnSalvar.setRequestFocusEnabled(false);
		btnSalvar.setFocusable(false);
		btnSalvar.setFocusTraversalKeysEnabled(false);
		btnSalvar.setFocusPainted(false);
		btnSalvar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSalvar.setForeground(new Color(0, 128, 255));
		btnSalvar.setFont(new Font("Arial", Font.BOLD, 12));
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salvarCliente();
				loadClienteData();
			}
		});
		btnSalvar.setBounds(471, 470, 123, 63);
		panelClientes.add(btnSalvar);		
		JButton btnLimparCampos = new JButton("");
		btnLimparCampos.setContentAreaFilled(false);
		btnLimparCampos.setBorder(null);
		btnLimparCampos.setRolloverEnabled(false);
		btnLimparCampos.setRequestFocusEnabled(false);
		btnLimparCampos.setFocusable(false);
		btnLimparCampos.setFocusTraversalKeysEnabled(false);
		btnLimparCampos.setFocusPainted(false);
		btnLimparCampos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimparCampos.setForeground(new Color(0, 128, 255));
		btnLimparCampos.setFont(new Font("Arial", Font.BOLD, 12));
		btnLimparCampos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Limpar todos os Campos de Uma Vez
				txtNomeCliente.setText(null);
				txtCpfCliente.setText(null);
				txtEnderecoCliente.setText(null); 
				txtTelefoneCliente.setText(null); 
				txtEmailCliente.setText(null);
			}
		});
		btnLimparCampos.setBounds(613, 470, 108, 63);
		panelClientes.add(btnLimparCampos);		
		
		JLabel lblFundo = new JLabel("");
		lblFundo.setIcon(new ImageIcon(MainPage.class.getResource("/img/wallclie.png")));
		lblFundo.setBounds(0, 0, 874, 692);
		panelClientes.add(lblFundo);
		
		 //Object [] column = {" "," "," "," "," "," "," "};
	     //tableModel.addColumn("ID");
		//------------------------Listar Clientes------------------------------------------
		JPanel panelListarClientes = new JPanel();
        tabPane.addTab("Clientes", null, panelListarClientes, null);
        panelListarClientes.setLayout(null);

        JScrollPane scrollPaneClientes = new JScrollPane();
        scrollPaneClientes.setBounds(46, 118, 784, 516);
        panelListarClientes.add(scrollPaneClientes);

        //loadClienteData();
        
        // Configuração da tabela e adição de colunas
        tableModelCliente = new DefaultTableModel();       
        tableModelCliente.addColumn("Nome");
        tableModelCliente.addColumn("CPF");
        tableModelCliente.addColumn("Endereco");
        tableModelCliente.addColumn("Telefone");
        tableModelCliente.addColumn("Email");
        
        loadClienteData(); // Carregar os dados da tabela
   
        // Configurando a tabela com o modelo e adicionando ao scrollPane
        tableClientes = new JTable(tableModelCliente);
        tableClientes.setFont(new Font("Arial", Font.PLAIN, 12));
        scrollPaneClientes.setViewportView(tableClientes);
				
		 JLabel lblNewLabel_1 = new JLabel("Filtrar por:");
		 lblNewLabel_1.setForeground(new Color(0, 128, 255));
		 lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 12));
		 lblNewLabel_1.setBounds(46, 93, 67, 14);
		 panelListarClientes.add(lblNewLabel_1);
		 		 
		 txtFiltroClientes = new JTextField();
		 txtFiltroClientes.setBounds(298, 87, 197, 24);
		 panelListarClientes.add(txtFiltroClientes);
		 txtFiltroClientes.setColumns(10);
		 		 
		 comboBoxClientes = new JComboBox<>(new String[]{"Nome","CPF","Endereço","Telefone","Email"});
		 comboBoxClientes.setRequestFocusEnabled(false);
		 comboBoxClientes.setOpaque(false);
		 comboBoxClientes.setLightWeightPopupEnabled(false);
		 comboBoxClientes.setFocusable(false);
		 comboBoxClientes.setFocusTraversalKeysEnabled(false);
		 comboBoxClientes.setForeground(new Color(0, 128, 255));
		 comboBoxClientes.setFont(new Font("Arial", Font.BOLD, 12));
		 comboBoxClientes.setBounds(123, 89, 165, 22);
		 panelListarClientes.add(comboBoxClientes);
		 
		 JButton btnFiltarCliente = new JButton("Filtrar");
		 btnFiltarCliente.setFocusable(false);
		 btnFiltarCliente.setDefaultCapable(false);
		 btnFiltarCliente.setContentAreaFilled(false);
		 btnFiltarCliente.setBorder(null);
		 btnFiltarCliente.setFocusTraversalKeysEnabled(false);
		 btnFiltarCliente.setFocusPainted(false);
		 btnFiltarCliente.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		 btnFiltarCliente.setForeground(new Color(0, 128, 255));
		 btnFiltarCliente.setFont(new Font("Arial", Font.BOLD, 12));
		 btnFiltarCliente.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		filtrarClientes();
		 	}
		 });
		 btnFiltarCliente.setBounds(505, 84, 89, 23);
		 panelListarClientes.add(btnFiltarCliente);
		 
		 btnRefreshClientes = new JButton("");
	     btnRefreshClientes.setBorderPainted(false);
	     btnRefreshClientes.setContentAreaFilled(false);
	     btnRefreshClientes.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	     btnRefreshClientes.setDefaultCapable(false);
	     btnRefreshClientes.setFocusTraversalKeysEnabled(false);
	     btnRefreshClientes.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent e) {
			 		loadClienteData();
			 	}
			 });
		 btnRefreshClientes.setBorder(null);
		 btnRefreshClientes.setIcon(new ImageIcon(MainPage.class.getResource("/img/refresh-17x17.png")));
		 btnRefreshClientes.setBounds(782, 84, 48, 23);
		 panelListarClientes.add(btnRefreshClientes);
		 
		 JLabel lblNewLabel_2 = new JLabel("");
		 lblNewLabel_2.setIcon(new ImageIcon(MainPage.class.getResource("/img/walllist.png")));
		 lblNewLabel_2.setBounds(0, 0, 874, 692);
		 panelListarClientes.add(lblNewLabel_2);
		
		//--------------------- Cadastrar Animal --------------------------------------------	
		JPanel panelAnimais = new JPanel();
		tabPane.addTab("New tab", null, panelAnimais, null);
		panelAnimais.setLayout(null);
		textAlergia = new JTextField();
		textAlergia.setBounds(73, 543, 250, 25);
		panelAnimais.add(textAlergia);		
		textCondicaoSaude = new JTextField();
		textCondicaoSaude.setBounds(472, 418, 250, 25);
		panelAnimais.add(textCondicaoSaude);		
		textRaca = new JTextField();
		textRaca.setBounds(73, 418, 250, 25);
		panelAnimais.add(textRaca);		
		textPorte = new JTextField();
		textPorte.setBounds(472, 293, 250, 25);
		panelAnimais.add(textPorte);		
		textPeso = new JTextField();
		textPeso.setBounds(73, 293, 250, 25);
		panelAnimais.add(textPeso);		
		textIdade = new JTextField();
		textIdade.setBounds(472, 161, 250, 25);
		panelAnimais.add(textIdade);		
		textNomeAnimal = new JTextField();
		textNomeAnimal.setBounds(73, 161, 250, 25);
		panelAnimais.add(textNomeAnimal);		
		JButton btnSalvarAnimal = new JButton("");
		btnSalvarAnimal.setContentAreaFilled(false);
		btnSalvarAnimal.setBorderPainted(false);
		btnSalvarAnimal.setBorder(null);
		btnSalvarAnimal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSalvarAnimal.setDefaultCapable(false);
		btnSalvarAnimal.setFocusable(false);
		btnSalvarAnimal.setFocusTraversalKeysEnabled(false);
		btnSalvarAnimal.setFocusPainted(false);
		btnSalvarAnimal.setForeground(new Color(0, 128, 255));
		btnSalvarAnimal.setFont(new Font("Arial", Font.BOLD, 12));
		btnSalvarAnimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salvarAnimal();
				loadAnimalData();				
				textAlergia.setText(null);
				textCondicaoSaude.setText(null);
				textRaca.setText(null);
				textPorte.setText(null);
				textPeso.setText(null);
				textIdade.setText(null);
				textNomeAnimal.setText(null);				
			}
		});
		btnSalvarAnimal.setBounds(474, 481, 112, 53);
		panelAnimais.add(btnSalvarAnimal);
		//-----------------------------------------------------
		
		JButton btnLimparAnimal = new JButton("");
		btnLimparAnimal.setContentAreaFilled(false);
		btnLimparAnimal.setBorderPainted(false);
		btnLimparAnimal.setBorder(null);
		btnLimparAnimal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimparAnimal.setDefaultCapable(false);
		btnLimparAnimal.setFocusable(false);
		btnLimparAnimal.setFocusTraversalKeysEnabled(false);
		btnLimparAnimal.setFocusPainted(false);
		btnLimparAnimal.setForeground(new Color(0, 128, 255));
		btnLimparAnimal.setFont(new Font("Arial", Font.BOLD, 12));
		btnLimparAnimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textAlergia.setText(null);
				textCondicaoSaude.setText(null);
				textRaca.setText(null);
				textPorte.setText(null);
				textPeso.setText(null);
				textIdade.setText(null);
				textNomeAnimal.setText(null);
			}
		});
		btnLimparAnimal.setBounds(615, 481, 100, 53);
		panelAnimais.add(btnLimparAnimal);	
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(MainPage.class.getResource("/img/wallanim.png")));
		lblNewLabel_4.setBounds(0, 0, 874, 692);
		panelAnimais.add(lblNewLabel_4);
		
	//-----------------Listar Animal-----------------------
			
		JPanel panelListarAnimais = new JPanel();
		panelListarAnimais.setFont(new Font("Arial", Font.BOLD, 12));
		panelListarAnimais.setFocusable(false);
		panelListarAnimais.setBorder(null);
		panelListarAnimais.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		panelListarAnimais.setFocusTraversalKeysEnabled(false);
		panelListarAnimais.setDoubleBuffered(false);
		tabPane.addTab("ListarAnimais", null, panelListarAnimais, null);
		panelListarAnimais.setLayout(null);
		
		JScrollPane scrollPaneAnimais = new JScrollPane();
		scrollPaneAnimais.setBounds(48, 117, 784, 516);
		panelListarAnimais.add(scrollPaneAnimais);
		
        // Configuração da tabela e adição de colunas
        tableModelAnimal = new DefaultTableModel();
        tableModelAnimal.addColumn("Nome");
        tableModelAnimal.addColumn("Idade");
        tableModelAnimal.addColumn("Peso");
        tableModelAnimal.addColumn("Porte");
        tableModelAnimal.addColumn("Raça");
        tableModelAnimal.addColumn("Condiçaõ");
        tableModelAnimal.addColumn("Alergia");


        // Carregar os dados da tabela
        loadAnimalData();
		
		tableAnimais = new JTable(tableModelAnimal);
		scrollPaneAnimais.setViewportView(tableAnimais);
		
		JLabel lblNewLabel_1_1 = new JLabel("Filtrar por:");
		lblNewLabel_1_1.setFont(new Font("Arial", Font.BOLD, 12));
		lblNewLabel_1_1.setForeground(new Color(0, 128, 255));
		lblNewLabel_1_1.setBounds(48, 92, 67, 14);
		panelListarAnimais.add(lblNewLabel_1_1);
		
		txtFiltroAnimal = new JTextField();
		txtFiltroAnimal.setColumns(10);
		txtFiltroAnimal.setBounds(300, 86, 197, 24);
		panelListarAnimais.add(txtFiltroAnimal);
		
		JButton btnFiltrarAnimais = new JButton("Filtrar");
		btnFiltrarAnimais.setContentAreaFilled(false);
		btnFiltrarAnimais.setBorderPainted(false);
		btnFiltrarAnimais.setFocusPainted(false);
		btnFiltrarAnimais.setFocusTraversalKeysEnabled(false);
		btnFiltrarAnimais.setFocusable(false);
		btnFiltrarAnimais.setFont(new Font("Arial", Font.BOLD, 12));
		btnFiltrarAnimais.setForeground(new Color(0, 128, 255));
		btnFiltrarAnimais.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				filtrarAnimais();
			}
		});
		btnFiltrarAnimais.setBounds(507, 83, 89, 23);
		panelListarAnimais.add(btnFiltrarAnimais);
				
		comboBoxAnimais = new JComboBox<>(new String[] {"Nome", "Raca", "Idade"});
		comboBoxAnimais.setFont(new Font("Arial", Font.BOLD, 12));
		comboBoxAnimais.setForeground(new Color(0, 128, 255));
		comboBoxAnimais.setBounds(125, 88, 165, 22);
		panelListarAnimais.add(comboBoxAnimais);
		
		btnRefreshAnimal = new JButton("");
		btnRefreshAnimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadAnimalData();
			}
		});
		btnRefreshAnimal.setIcon(new ImageIcon(MainPage.class.getResource("/img/refresh-17x17.png")));
		btnRefreshAnimal.setContentAreaFilled(false);
		btnRefreshAnimal.setBorder(null);
		btnRefreshAnimal.setBounds(787, 92, 45, 23);
		panelListarAnimais.add(btnRefreshAnimal);
		
		JLabel lblFundoList2 = new JLabel("");
		lblFundoList2.setIcon(new ImageIcon(MainPage.class.getResource("/img/walllist.png")));
		lblFundoList2.setBounds(0, 0, 874, 692);
		panelListarAnimais.add(lblFundoList2);
				
		//---------------------COMEÇO DO PANE AGENDAMENTO-----------------------------------------------
		JPanel panelAgendamento = new JPanel();
		tabPane.addTab("New tab", null, panelAgendamento, null);
		panelAgendamento.setLayout(null);
		
		
		JLabel lblTipo_1 = new JLabel("Serviço:");
		lblTipo_1.setForeground(new Color(0, 128, 192));
		lblTipo_1.setFont(new Font("Arial", Font.BOLD, 12));
		lblTipo_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTipo_1.setBounds(10, 58, 80, 25);
		panelAgendamento.add(lblTipo_1);
		
		
		JLabel lblData_1 = new JLabel("Data:");
		lblData_1.setForeground(new Color(0, 128, 192));
		lblData_1.setFont(new Font("Arial", Font.BOLD, 12));
		lblData_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblData_1.setBounds(585, 94, 46, 25);
		panelAgendamento.add(lblData_1);	
		
		
		JLabel lblHora_1 = new JLabel("Horário:");
		lblHora_1.setForeground(new Color(0, 128, 192));
		lblHora_1.setFont(new Font("Arial", Font.BOLD, 12));
		lblHora_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblHora_1.setBounds(10, 94, 80, 25);
		panelAgendamento.add(lblHora_1);	
		
		
		JLabel lblValor_1 = new JLabel("Valor:");
		lblValor_1.setForeground(new Color(0, 128, 192));
		lblValor_1.setFont(new Font("Arial", Font.BOLD, 12));
		lblValor_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblValor_1.setBounds(279, 56, 80, 25);
		panelAgendamento.add(lblValor_1);	
		
		
		JButton btnSalvarAgendamento = new JButton("Salvar");
		btnSalvarAgendamento.setForeground(new Color(0, 128, 192));
		btnSalvarAgendamento.setFont(new Font("Arial", Font.BOLD, 12));
		btnSalvarAgendamento.setHorizontalTextPosition(SwingConstants.CENTER);
		btnSalvarAgendamento.setVerticalTextPosition(SwingConstants.CENTER);
		btnSalvarAgendamento.setBackground(Color.RED);
		btnSalvarAgendamento.setBorderPainted(false);
		btnSalvarAgendamento.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSalvarAgendamento.setBorder(null);
		btnSalvarAgendamento.setRequestFocusEnabled(false);
		btnSalvarAgendamento.setOpaque(false);
		btnSalvarAgendamento.setFocusable(false);
		btnSalvarAgendamento.setFocusTraversalKeysEnabled(false);
		btnSalvarAgendamento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salvarAgendamento();
				loadAgendamentoData();
			}
		});
		btnSalvarAgendamento.setBounds(100, 138, 128, 25);
		panelAgendamento.add(btnSalvarAgendamento);	
		
		
		JButton btnLimparCamposAgendamento = new JButton("Limpar Campos");		
		btnLimparCamposAgendamento.setForeground(new Color(0, 128, 192));
		btnLimparCamposAgendamento.setFont(new Font("Arial", Font.BOLD, 12));
		btnLimparCamposAgendamento.setHorizontalTextPosition(SwingConstants.CENTER);
		btnLimparCamposAgendamento.setVerticalTextPosition(SwingConstants.CENTER);
		btnLimparCamposAgendamento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDataAgen.setText(null);
				txtNomeClienteAgen.setText(null);
				//comboBoxHora.setToolTipText(null);
				//txtDataAgen.setText(null);				
			}
		});
		btnLimparCamposAgendamento.setBackground(Color.RED);
		btnLimparCamposAgendamento.setBorderPainted(false);
		btnLimparCamposAgendamento.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimparCamposAgendamento.setBorder(null);
		btnLimparCamposAgendamento.setRequestFocusEnabled(false);
		btnLimparCamposAgendamento.setOpaque(false);
		btnLimparCamposAgendamento.setFocusable(false);
		btnLimparCamposAgendamento.setFocusTraversalKeysEnabled(false);
		btnLimparCamposAgendamento.setBounds(216, 138, 128, 25);
		panelAgendamento.add(btnLimparCamposAgendamento);		
		JLabel lblFiltro_2 = new JLabel("Filtrar por:");
		lblFiltro_2.setForeground(new Color(0, 128, 192));
		lblFiltro_2.setFont(new Font("Arial", Font.BOLD, 12));
		lblFiltro_2.setBounds(68, 191, 80, 20);
		panelAgendamento.add(lblFiltro_2);		
		txtFiltroAgen = new JTextField();
		txtFiltroAgen.setBounds(324, 191, 217, 20);
		panelAgendamento.add(txtFiltroAgen);
		
		//----------------Botão para Filtrar Agendamentos-----------------
		JButton btnFiltrarAgen = new JButton("Filtrar");
		btnFiltrarAgen.setForeground(new Color(0, 128, 192));
		btnFiltrarAgen.setFont(new Font("Arial", Font.BOLD, 12));
		btnFiltrarAgen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				filtrarAgendamento();
			}
		});
		btnFiltrarAgen.setHorizontalTextPosition(SwingConstants.CENTER);
		btnFiltrarAgen.setVerticalTextPosition(SwingConstants.CENTER);
		btnFiltrarAgen.setBackground(Color.RED);
		btnFiltrarAgen.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnFiltrarAgen.setBorder(null);
		btnFiltrarAgen.setRequestFocusEnabled(false);
		btnFiltrarAgen.setOpaque(false);
		btnFiltrarAgen.setFocusable(false);
		btnFiltrarAgen.setFocusTraversalKeysEnabled(false);
		btnFiltrarAgen.setBounds(551, 191, 147, 20);
		panelAgendamento.add(btnFiltrarAgen);		
		JScrollPane scrollPane_2 = new JScrollPane((Component) null);
		scrollPane_2.setBounds(46, 223, 784, 405);
		panelAgendamento.add(scrollPane_2);		
		
		tableModelAgendamento = new DefaultTableModel();
        tableModelAgendamento.addColumn("Data");
        tableModelAgendamento.addColumn("Horario");
        tableModelAgendamento.addColumn("Servico");
        tableModelAgendamento.addColumn("Valor");
        tableModelAgendamento.addColumn("Status");


        // Carregar os dados da tabela
        loadAgendamentoData();
        
        tableAgendamento = new JTable(tableModelAgendamento);
		scrollPane_2.setViewportView(tableAgendamento);
		
		
		comboBoxAgendamentoFiltro = new JComboBox<String>(new String[] {"Data", "Servico"});
		comboBoxAgendamentoFiltro.setForeground(new Color(0, 128, 255));
		comboBoxAgendamentoFiltro.setFont(new Font("Arial", Font.BOLD, 12));
		comboBoxAgendamentoFiltro.setRequestFocusEnabled(false);
		comboBoxAgendamentoFiltro.setOpaque(false);
		comboBoxAgendamentoFiltro.setLightWeightPopupEnabled(false);
		comboBoxAgendamentoFiltro.setFocusable(false);
		comboBoxAgendamentoFiltro.setFocusTraversalKeysEnabled(false);
		comboBoxAgendamentoFiltro.setAlignmentX(Component.RIGHT_ALIGNMENT);
		comboBoxAgendamentoFiltro.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		comboBoxAgendamentoFiltro.setBorder(null);
		comboBoxAgendamentoFiltro.setBounds(158, 190, 156, 22);
		panelAgendamento.add(comboBoxAgendamentoFiltro);
		
		txtDataAgen =  new JTextField();					
		txtDataAgen.setBounds(641, 96, 170, 25);
		panelAgendamento.add(txtDataAgen);
		
		// Criar JComboBox para serviços
		comboBoxServico = new JComboBox<>(new String[] {"Selecione um Servico", "Banho", "Tosa", "Banho e Tosa", "Passeio", "Adestramento"});
		comboBoxServico.setForeground(new Color(0, 128, 255));
		comboBoxServico.setFont(new Font("Arial", Font.BOLD, 12));
		comboBoxServico.setBorder(null);
		comboBoxServico.setRequestFocusEnabled(false);
		comboBoxServico.setOpaque(false);
		comboBoxServico.setLightWeightPopupEnabled(false);
		comboBoxServico.setFocusable(false);
		comboBoxServico.setFocusTraversalKeysEnabled(false);
		comboBoxServico.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		comboBoxServico.setBounds(100, 56, 169, 27);
		panelAgendamento.add(comboBoxServico);

		// Criar JComboBox para horários
		comboBoxHora = new JComboBox<>(new String[] {"09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00"});
		comboBoxHora.setForeground(new Color(0, 128, 255));
		comboBoxHora.setFont(new Font("Arial", Font.BOLD, 12));
		comboBoxHora.setBorder(null);
		comboBoxHora.setRequestFocusEnabled(false);
		comboBoxHora.setOpaque(false);
		comboBoxHora.setLightWeightPopupEnabled(false);
		comboBoxHora.setFocusable(false);
		comboBoxHora.setFocusTraversalKeysEnabled(false);
		comboBoxHora.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		comboBoxHora.setBounds(100, 93, 169, 24);
		panelAgendamento.add(comboBoxHora);

		// Criar JComboBox para status
		comboBoxStatus = new JComboBox<>(new String[] {"Pendente", "Cancelado"});
		comboBoxStatus.setForeground(new Color(0, 128, 255));
		comboBoxStatus.setFont(new Font("Arial", Font.BOLD, 12));
		comboBoxStatus.setBorder(null);
		comboBoxStatus.setRequestFocusEnabled(false);
		comboBoxStatus.setOpaque(false);
		comboBoxStatus.setLightWeightPopupEnabled(false);
		comboBoxStatus.setFocusable(false);
		comboBoxStatus.setFocusTraversalKeysEnabled(false);
		comboBoxStatus.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		comboBoxStatus.setBounds(641, 57, 170, 26);
		panelAgendamento.add(comboBoxStatus);

		// Adicionar JLabel para status
		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
		lblStatus.setForeground(new Color(0, 128, 192));
		lblStatus.setFont(new Font("Arial", Font.BOLD, 12));
		lblStatus.setBounds(585, 58, 46, 19);
		panelAgendamento.add(lblStatus);

		// Criar JComboBox para valores
		comboBoxValor = new JComboBox<>();
		comboBoxValor.setForeground(new Color(0, 128, 255));
		comboBoxValor.setFont(new Font("Arial", Font.BOLD, 12));
		comboBoxValor.setBorder(null);
		comboBoxValor.setRequestFocusEnabled(false);
		comboBoxValor.setOpaque(false);
		comboBoxValor.setLightWeightPopupEnabled(false);
		comboBoxValor.setFocusable(false);
		comboBoxValor.setFocusTraversalKeysEnabled(false);
		comboBoxValor.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		comboBoxValor.setBounds(369, 56, 169, 26);
		panelAgendamento.add(comboBoxValor);
		
		JButton btnRefreshAgen = new JButton("");
		btnRefreshAgen.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnRefreshAgen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadAgendamentoData();
			}
		});
		btnRefreshAgen.setIcon(new ImageIcon(MainPage.class.getResource("/img/refresh-17x17.png")));
		btnRefreshAgen.setContentAreaFilled(false);
		btnRefreshAgen.setBorder(null);
		btnRefreshAgen.setBounds(785, 190, 45, 23);
		panelAgendamento.add(btnRefreshAgen);
		
		JLabel lblNomeCliente = new JLabel("Nome Cliente:");
		lblNomeCliente.setFont(new Font("Arial", Font.BOLD, 12));
		lblNomeCliente.setForeground(new Color(0, 128, 192));
		lblNomeCliente.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNomeCliente.setBounds(279, 97, 82, 14);
		panelAgendamento.add(lblNomeCliente);
		
		txtNomeClienteAgen = new JTextField();
		txtNomeClienteAgen.setBounds(371, 94, 170, 25);
		panelAgendamento.add(txtNomeClienteAgen);
		txtNomeClienteAgen.setColumns(10);
		
		JLabel lblFUNDO2 = new JLabel("");
		lblFUNDO2.setIcon(new ImageIcon(MainPage.class.getResource("/img/walllist.png")));
		lblFUNDO2.setBounds(0, 0, 874, 692);
		panelAgendamento.add(lblFUNDO2);

		// Adicionar ActionListener ao comboBoxServico
		comboBoxServico.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Limpar os itens anteriores do comboBoxValor
		        comboBoxValor.removeAllItems();
		        
		        // Pegar o valor do comboBoxServico
		        String valorservico = (String) comboBoxServico.getSelectedItem();

		        // Adicionar o preço correspondente ao comboBoxValor
		        if ("Banho".equals(valorservico)) {
		            comboBoxValor.addItem("R$ 60,00");
		        } else if ("Tosa".equals(valorservico)) {
		            comboBoxValor.addItem("R$ 40,00");
		        } else if ("Banho e Tosa".equals(valorservico)) {
		            comboBoxValor.addItem("R$ 100,00");
		        } else if ("Passeio".equals(valorservico)) {
		            comboBoxValor.addItem("R$ 30,00");
		        } else if ("Adestramento".equals(valorservico)) {
		            comboBoxValor.addItem("R$ 250,00");
		        } else {
		            comboBoxValor.addItem("Selecione um Servico");
		        }
		    }
		});
		
		//---------------------FIM DO PANE AGENDAMENTO-----------------------------------------------
		
		//Date thisDate = new Date();
		
		//---------------- Pane Menu ---------------------
		JPanel panelPrincipal = new JPanel();
		panelPrincipal.setBounds(0, 0, 203, 720);
		contentPane.add(panelPrincipal);
		panelPrincipal.setLayout(null);		
		JButton btnMenuPrincipal = new JButton("");
		btnMenuPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				tabPane.setSelectedIndex(0);
				
				new MainPage().dispose();
				
			}
		});
		btnMenuPrincipal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMenuPrincipal.setFont(new Font("Arial", Font.BOLD, 12));
		btnMenuPrincipal.setForeground(Color.WHITE);
		btnMenuPrincipal.setFocusable(false);
		btnMenuPrincipal.setFocusTraversalKeysEnabled(false);
		btnMenuPrincipal.setFocusPainted(false);
		btnMenuPrincipal.setBorderPainted(false);
		btnMenuPrincipal.setContentAreaFilled(false);
		btnMenuPrincipal.setBorder(null);
		btnMenuPrincipal.setBounds(10, 43, 183, 100);
		panelPrincipal.add(btnMenuPrincipal);			
		JButton btnClientes = new JButton("");
		btnClientes.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabPane.setSelectedIndex(2);
			}
		});
		btnClientes.setForeground(Color.WHITE);
		btnClientes.setFont(new Font("Arial", Font.BOLD, 12));
		btnClientes.setFocusable(false);
		btnClientes.setFocusTraversalKeysEnabled(false);
		btnClientes.setFocusPainted(false);
		btnClientes.setContentAreaFilled(false);
		btnClientes.setBorderPainted(false);
		btnClientes.setBorder(null);
		btnClientes.setBounds(10, 255, 183, 23);
		panelPrincipal.add(btnClientes);	
		JButton btnListarClientes = new JButton("");
		btnListarClientes.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnListarClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabPane.setSelectedIndex(3);
			}
		});
		btnListarClientes.setForeground(Color.WHITE);
		btnListarClientes.setFont(new Font("Arial", Font.BOLD, 12));
		btnListarClientes.setFocusable(false);
		btnListarClientes.setFocusTraversalKeysEnabled(false);
		btnListarClientes.setFocusPainted(false);
		btnListarClientes.setContentAreaFilled(false);
		btnListarClientes.setBorderPainted(false);
		btnListarClientes.setBorder(null);
		btnListarClientes.setBounds(10, 408, 183, 23);
		panelPrincipal.add(btnListarClientes);		
		JButton btnAnimais = new JButton("");
		btnAnimais.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabPane.setSelectedIndex(4);
			}
		});
		btnAnimais.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAnimais.setForeground(Color.WHITE);
		btnAnimais.setFont(new Font("Arial", Font.BOLD, 12));
		btnAnimais.setFocusable(false);
		btnAnimais.setFocusTraversalKeysEnabled(false);
		btnAnimais.setFocusPainted(false);
		btnAnimais.setContentAreaFilled(false);
		btnAnimais.setBorderPainted(false);
		btnAnimais.setBorder(null);
		btnAnimais.setBounds(10, 279, 183, 31);
		panelPrincipal.add(btnAnimais);				
		JButton btnListarAnimais = new JButton("");
		btnListarAnimais.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabPane.setSelectedIndex(5);
				//loadAnimalData();
			}
		});
		btnListarAnimais.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnListarAnimais.setForeground(Color.WHITE);
		btnListarAnimais.setFont(new Font("Arial", Font.BOLD, 12));
		btnListarAnimais.setFocusable(false);
		btnListarAnimais.setFocusTraversalKeysEnabled(false);
		btnListarAnimais.setFocusPainted(false);
		btnListarAnimais.setContentAreaFilled(false);
		btnListarAnimais.setBorderPainted(false);
		btnListarAnimais.setBorder(null);
		btnListarAnimais.setBounds(10, 434, 183, 23);
		panelPrincipal.add(btnListarAnimais);			
		JButton btnAgendamento = new JButton("");
		btnAgendamento.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAgendamento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabPane.setSelectedIndex(6);
			}
		});
		btnAgendamento.setForeground(Color.WHITE);
		btnAgendamento.setFont(new Font("Arial", Font.BOLD, 12));
		btnAgendamento.setFocusable(false);
		btnAgendamento.setFocusTraversalKeysEnabled(false);
		btnAgendamento.setFocusPainted(false);
		btnAgendamento.setContentAreaFilled(false);
		btnAgendamento.setBorderPainted(false);
		btnAgendamento.setBorder(null);
		btnAgendamento.setBounds(10, 563, 183, 23);
		panelPrincipal.add(btnAgendamento);		
		JButton btnListarAgendamentos = new JButton("");
		btnListarAgendamentos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabPane.setSelectedIndex(1);
			}
		});
		btnListarAgendamentos.setForeground(Color.WHITE);
		btnListarAgendamentos.setFont(new Font("Arial", Font.BOLD, 12));
		btnListarAgendamentos.setFocusable(false);
		btnListarAgendamentos.setFocusTraversalKeysEnabled(false);
		btnListarAgendamentos.setFocusPainted(false);
		btnListarAgendamentos.setContentAreaFilled(false);
		btnListarAgendamentos.setBorderPainted(false);
		btnListarAgendamentos.setBorder(null);
		btnListarAgendamentos.setBounds(48, 597, 89, 17);
		panelPrincipal.add(btnListarAgendamentos);
		
		JButton btnAdmin = new JButton("");
		btnAdmin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new LoginAdmin().setVisible(true); //Abre a janela MainPage
				dispose(); //Fecha a janela de login
			}
		});
		btnAdmin.setContentAreaFilled(false);
		btnAdmin.setBorderPainted(false);
		btnAdmin.setBorder(null);
		btnAdmin.setBounds(48, 620, 89, 23);
		panelPrincipal.add(btnAdmin);
		
		JLabel lblAgendamento = new JLabel("");
		lblAgendamento.setIcon(new ImageIcon(MainPage.class.getResource("/img/Design sem nome.png")));
		lblAgendamento.setBounds(0, 0, 203, 720);
		panelPrincipal.add(lblAgendamento);
		//-------------------------------------------				
		JLabel lblMinimiWin = new JLabel("");
		lblMinimiWin.setBounds(1014, 0, 30, 34);
		panelBarra.add(lblMinimiWin);
		lblMinimiWin.setFocusable(false);
		lblMinimiWin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setState(ICONIFIED);
			}	
		});
		lblMinimiWin.setIcon(new ImageIcon(MainPage.class.getResource("/img/minus.png")));
		lblMinimiWin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblMinimiWin.setHorizontalAlignment(SwingConstants.CENTER);
		lblMinimiWin.setForeground(Color.WHITE);
		lblMinimiWin.setToolTipText("");
		lblMinimiWin.setLabelFor(panelBarra);			
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//setUndecorated(true);				
	}
	
	private void loadClienteData() {
        try {
            Connection conexao = ConnectionFactory.createConnection();
            String sql = "SELECT * FROM clientes";
            PreparedStatement cmd = conexao.prepareStatement(sql);
            ResultSet resultado = cmd.executeQuery();
            
            // Limpar a tabela antes de atualizar
            tableModelCliente.setRowCount(1);

            // Preencher o modelo da tabela com os dados do banco de dados
            while (resultado.next()) {
                Vector<String> row = new Vector<>();
                row.add(resultado.getString("nome"));
                row.add(resultado.getString("cpf"));
                row.add(resultado.getString("endereco"));
                row.add(resultado.getString("telefone"));
                row.add(resultado.getString("email"));
                
                tableModelCliente.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao carregar dados: " + e.getMessage());
        }
    }
	
    // Método para salvar um novo cliente e atualizar a tabela
    private void salvarCliente() {
        String nome = txtNomeCliente.getText();
        String cpf = txtCpfCliente.getText();
        String endereco = txtEnderecoCliente.getText();
        String telefone = txtTelefoneCliente.getText();
        String email = txtEmailCliente.getText();

        try (Connection conexao = ConnectionFactory.createConnection()) {  // Abre e fecha a conexão automaticamente
            String sql = "INSERT INTO clientes (nome, cpf, endereco, telefone, email) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = conexao.prepareStatement(sql);
            statement.setString(1, nome);
            statement.setString(2, cpf);
            statement.setString(3, endereco);
            statement.setString(4, telefone);
            statement.setString(5, email);
            statement.executeUpdate();

            JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso!");
            
            // Limpar os campos de texto
            txtNomeCliente.setText("");
            txtCpfCliente.setText("");
            txtEnderecoCliente.setText("");
            txtTelefoneCliente.setText("");
            txtEmailCliente.setText("");
            
            // Atualizar a tabela imediatamente
            loadClienteData();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao salvar cliente: " + ex.getMessage());
        }
    }
	
	
	private void filtrarClientes() {
        String filtroCliente = txtFiltroClientes.getText().trim();
        String colunaCliente = comboBoxClientes.getSelectedItem().toString().toLowerCase();
        
        if (filtroCliente.isEmpty()) {
            loadAgendamentoData();  // Se o campo estiver vazio, mostrar todos os dados
            return;
        }

        try (Connection conexao = ConnectionFactory.createConnection()) { // Abre e fecha a conexão automaticamente
        	
            String sql = "SELECT nome, cpf, endereco, telefone, email FROM clientes WHERE " + colunaCliente + " LIKE ?";
            PreparedStatement cmd = conexao.prepareStatement(sql);
            cmd.setString(1, "%" + filtroCliente + "%");  // Usar wildcard para busca parcial
            ResultSet resultado = cmd.executeQuery();

            tableModelCliente.setRowCount(0);  // Limpar dados atuais

            while (resultado.next()) {
                Vector<String> row = new Vector<>();
                //row.add(String.valueOf(resultado.getInt("id")));
                row.add(resultado.getString("nome"));
				row.add(resultado.getString("cpf"));
				row.add(resultado.getString("endereco"));
				row.add(resultado.getString("telefone"));
				row.add(resultado.getString("email"));
				

                tableModelCliente.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	//Método que salva os dados do animal no banco de dados
	private void salvarAnimal() {
	    String nome = textNomeAnimal.getText();
	    String idade = textIdade.getText();
	    String peso = textPeso.getText();
	    String porte = textPorte.getText();
	    String raca = textRaca.getText();
	    String condicaoSaude = textCondicaoSaude.getText();
	    String alergia = textAlergia.getText();	

	    try {
	    	Connection conexao = ConnectionFactory.createConnection();
	        String sql = "INSERT INTO animais (nome, idade, peso, porte, raca, condicao_saude, alergia) VALUES (?, ?, ?, ?, ?, ?, ?)";
	        PreparedStatement statement = conexao.prepareStatement(sql);
	        statement.setString(1, nome);
	        statement.setString(2, idade);
	        statement.setString(3, peso);
	        statement.setString(4, porte);
	        statement.setString(5, raca);
	        statement.setString(6, condicaoSaude);
	        statement.setString(7, alergia);	
	        int rowsInserted = statement.executeUpdate();
	        if (rowsInserted > 0) {
	            JOptionPane.showMessageDialog(null, "Animal cadastrado com sucesso!");
	            //Limpar campos após o cadastro for bem sucvwedido
				textAlergia.setText(null);
				textCondicaoSaude.setText(null);
				textRaca.setText(null);
				textPorte.setText(null);
				textPeso.setText(null);
				textIdade.setText(null);
				textNomeAnimal.setText(null);
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Erro ao cadastrar animal: " + ex.getMessage());
	    }
	}	
	
    private void loadAnimalData() {
		try {
			
			Connection conexao = ConnectionFactory.createConnection();
			String sql = "select * from animais";
			
			PreparedStatement cmd = conexao.prepareStatement(sql);
			ResultSet resultado = cmd.executeQuery();
			
			tableModelAnimal.setRowCount(0);
			
			while(resultado.next()) {
				Vector<String> row = new Vector<>();
				//row.add(String.valueOf(resultado.getInt("id")));
				row.add(resultado.getString("nome"));
				row.add(resultado.getString("idade"));
				row.add(resultado.getString("peso"));
				row.add(resultado.getString("porte"));
				row.add(resultado.getString("raca"));
				row.add(resultado.getString("condicao_saude"));
				row.add(resultado.getString("alergia"));
				
				
				tableModelAnimal.addRow(row);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    private void filtrarAnimais() {
        String filtro = txtFiltroAnimal.getText().trim();
        String coluna = comboBoxAnimais.getSelectedItem().toString().toLowerCase();

        if (filtro.isEmpty()) {
            loadAnimalData();  // Se o campo estiver vazio, mostrar todos os dados
            return;
        }

        try {
            Connection conexao = ConnectionFactory.createConnection();
            String sql = "SELECT nome, raca, idade, peso, porte, condicao_saude, alergia FROM animais WHERE " + coluna + " LIKE ?";
            PreparedStatement cmd = conexao.prepareStatement(sql);
            cmd.setString(1, "%" + filtro + "%");  // Usar wildcard para busca parcial
            ResultSet resultado = cmd.executeQuery();

            tableModelAnimal.setRowCount(0);  // Limpar dados atuais

            while (resultado.next()) {
                Vector<String> row = new Vector<>();
                //row.add(String.valueOf(resultado.getInt("id")));
                row.add(resultado.getString("nome"));
                row.add(resultado.getString("idade"));
                row.add(resultado.getString("peso"));
                row.add(resultado.getString("porte"));
                row.add(resultado.getString("raca"));
                row.add(resultado.getString("condicao_saude"));
                row.add(resultado.getString("alergia"));


                tableModelAnimal.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

 // Método que salva os dados do agendamento no banco de dados
    private void salvarAgendamento() {
    	   	 	
    	String nome = txtNomeClienteAgen.getText();
        String data_agendamento = txtDataAgen.getText();
        String horario = comboBoxHora.getSelectedItem().toString();
        String servico = comboBoxServico.getSelectedItem().toString();
        String valor = comboBoxValor.getSelectedItem().toString();
        String status = comboBoxStatus.getSelectedItem().toString();
   
        try {
        	Connection conexao = ConnectionFactory.createConnection();
            String sql = "INSERT INTO agendamentos (nome, data_agendamento, horario, servico, valor, status) VALUES (?, ?, ?, ?, ?, ?)";
            
            PreparedStatement statement = conexao.prepareStatement(sql);
             
            statement.setString(1, nome);
            statement.setString(2, data_agendamento);
            statement.setString(3, horario);
            statement.setString(4, servico);           
            statement.setString(5, valor);
            statement.setString(6, status);
                                          
            int rowsInserted = statement.executeUpdate();            
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(contentPane, "Agendado com sucesso!");
                //Limpar apos agendar
                /*
				textFieldValor.setText(null);
				comboBoxServico.setToolTipText(null);
				comboBoxHora.setToolTipText(null);
				txtDataAgen.setText(null);	
				*/
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(contentPane, "Erro ao Ae: " + ex.getMessage());
        }
    }
    
    private void loadAgendamentoData() {
		try {
			
			Connection conexao = ConnectionFactory.createConnection();
			String sql = "select * from agendamentos";
			
			PreparedStatement cmd = conexao.prepareStatement(sql);
			ResultSet resultado = cmd.executeQuery();
			
			tableModelAgendamento.setRowCount(0);
			
			while(resultado.next()) {
				Vector<String> row = new Vector<>();
				//row.add(String.valueOf(resultado.getInt("id")));
				row.add(resultado.getString("data_agendamento"));
				row.add(resultado.getString("horario"));
				row.add(resultado.getString("servico"));
				row.add(resultado.getString("valor"));
				row.add(resultado.getString("status"));
				row.add(resultado.getString("nome"));
				
				tableModelAgendamento.addRow(row);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    private void filtrarAgendamento() {
        String filtro = txtFiltroAgen.getText().trim();
        String coluna = comboBoxAgendamentoFiltro.getSelectedItem().toString().toLowerCase();

        if (filtro.isEmpty()) {
            loadAgendamentoData();  // Se o campo estiver vazio, mostrar todos os dados
            return;
        }

        try {
            Connection conexao = ConnectionFactory.createConnection();
            String sql = "SELECT data_agendamento, horario, servico, valor, status FROM agendamentos WHERE " + coluna + " LIKE ?";
            PreparedStatement cmd = conexao.prepareStatement(sql);
            cmd.setString(1, "%" + filtro + "%");  // Usar wildcard para busca parcial
            ResultSet resultado = cmd.executeQuery();

            tableModelAgendamento.setRowCount(0);  // Limpar dados atuais

            while (resultado.next()) {
                Vector<String> row = new Vector<>();
                //row.add(String.valueOf(resultado.getInt("id")));
				row.add(resultado.getString("data_agendamento"));
				row.add(resultado.getString("horario"));
				row.add(resultado.getString("servico"));
				row.add(resultado.getString("valor"));
				row.add(resultado.getString("status"));

                tableModelAgendamento.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }   
}