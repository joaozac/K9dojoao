package Main;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import BCrypts.BCryptUtil;
import JDBC.ConnectionFactory;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EditarFuncionario extends JFrame {
    private JTextField txtId, txtUsername;
    private JPasswordField txtSenha, txtConfSenha;
    private JComboBox<String> cmbCargo;
    private JCheckBox ckbStatus;
    private String userId;
    private Admin usuList; // Referência para UsuList
    private JPanel contentPane;

    // Construtor que recebe a referência de UsuList
    public EditarFuncionario(String userId, Admin usuList) {
        this.userId = userId;
        this.usuList = usuList; // Armazena a referência de UsuList
        setTitle("Atualizar Usuário");
        setBounds(100, 100, 600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        txtId = new JTextField();
        txtId.setFont(new Font("Arial", Font.PLAIN, 12));
        txtId.setEditable(false);
        txtId.setBounds(231, 58, 107, 20);
        contentPane.add(txtId);
        txtId.setColumns(10);

        txtUsername = new JTextField();
        txtUsername.setFont(new Font("Arial", Font.PLAIN, 12));
        txtUsername.setEditable(false);
        txtUsername.setColumns(10);
        txtUsername.setBounds(231, 102, 229, 20);
        contentPane.add(txtUsername);

        txtSenha = new JPasswordField();
        txtSenha.setFont(new Font("Arial", Font.PLAIN, 12));
        txtSenha.setBounds(229, 149, 265, 20);
        contentPane.add(txtSenha);

        txtConfSenha = new JPasswordField();
        txtConfSenha.setFont(new Font("Arial", Font.PLAIN, 12));
        txtConfSenha.setBounds(231, 196, 265, 20);
        contentPane.add(txtConfSenha);

        cmbCargo = new JComboBox<>(new String[]{"Gerente", "Tosador", "Caixa", "Adestrador", "Admin"});
        cmbCargo.setBounds(231, 240, 266, 22);
        contentPane.add(cmbCargo);

        ckbStatus = new JCheckBox("Ativo");
        ckbStatus.setFont(new Font("Arial", Font.PLAIN, 12));
        ckbStatus.setBounds(231, 284, 97, 23);
        contentPane.add(ckbStatus);

        JButton btnSave = new JButton("");
        btnSave.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnSave.setContentAreaFilled(false);
        btnSave.setBorderPainted(false);
        btnSave.setBorder(null);
        btnSave.setFont(new Font("Arial", Font.PLAIN, 12));
        btnSave.setBounds(421, 273, 73, 34);
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    updateUser();
                }
            }
        });
        contentPane.add(btnSave);

        JButton btnCancel = new JButton(".");
        btnCancel.setContentAreaFilled(false);
        btnCancel.setBorderPainted(false);
        btnCancel.setFont(new Font("Arial", Font.PLAIN, 12));
        btnCancel.setBounds(504, 284, 73, 23);
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnCancel);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(EditarFuncionario.class.getResource("/img/fundoEdit.png")));
        lblNewLabel.setBounds(0, 0, 584, 369);
        contentPane.add(lblNewLabel);

        loadUserData();
    }

    private void loadUserData() {
        try {
            Connection conexao = ConnectionFactory.createConnection();
            String sql = "SELECT id, username, nome, cargo, status FROM funcionarios WHERE id = ?";
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setString(1, userId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                txtId.setText(rs.getString("id"));
                txtUsername.setText(rs.getString("username"));
                
                cmbCargo.setSelectedItem(rs.getString("cargo"));
                ckbStatus.setSelected(rs.getString("status").equals("Ativo"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean validateFields() {
        if (txtUsername.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nome de Usuário não pode estar vazio.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
       
        if (txtSenha.getPassword().length > 0) {
            if (!new String(txtSenha.getPassword()).equals(new String(txtConfSenha.getPassword()))) {
                JOptionPane.showMessageDialog(this, "As senhas não conferem.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return true;
    }

    private void updateUser() {
        try {
            Connection conexao = ConnectionFactory.createConnection();
            String sql = "UPDATE funcionarios SET cargo = ?, status = ?";
            if (txtSenha.getPassword().length > 0) {
                sql += ", senha = ?";
            }
            sql += " WHERE id = ?";

            PreparedStatement pst = conexao.prepareStatement(sql);

            pst.setString(1, cmbCargo.getSelectedItem().toString());
            pst.setString(2, ckbStatus.isSelected() ? "Ativo" : "Inativo");

            int paramIndex = 3; // Índice para o próximo parâmetro
            if (txtSenha.getPassword().length > 0) {
                String hashSenha = BCryptUtil.hashPassword(new String(txtSenha.getPassword()));
                pst.setString(paramIndex++, hashSenha);
            }

            pst.setString(paramIndex, userId);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Usuário atualizado com sucesso!");

                // Atualiza a lista de usuários na tabela da UsuList
                if (usuList != null) {
                    usuList.loadAllUsers();
                }

                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao atualizar o usuário.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao atualizar o usuário.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new EditarFuncionario("1", null).setVisible(true); // Chamando sem UsuList para teste
        });
    }
}
