package Main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BCrypts.BCryptUtil;
import JDBC.ConnectionFactory;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Cursor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class LoginAdmin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField pswSenha;
	private JTextField txtUsername;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginAdmin frame = new LoginAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginAdmin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 595);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false); // Desativa o redimensionamento da janela

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 384, 556);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnLoginAdmin = new JButton("Logar");
		btnLoginAdmin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLoginAdmin.setIcon(new ImageIcon(LoginAdmin.class.getResource("/img/Login-17x17.png")));
		btnLoginAdmin.setOpaque(false);
		btnLoginAdmin.setRolloverEnabled(false);
		btnLoginAdmin.setRequestFocusEnabled(false);
		btnLoginAdmin.setContentAreaFilled(false);
		btnLoginAdmin.setBorder(null);
		btnLoginAdmin.setFocusable(false);
		btnLoginAdmin.setFocusTraversalKeysEnabled(false);
		btnLoginAdmin.setFocusPainted(false);
		btnLoginAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login(); //Abre a janela MainPage
				dispose(); //Fecha a janela de login
			}
		});
		btnLoginAdmin.setBounds(133, 457, 122, 23);
		panel.add(btnLoginAdmin);
		
		//setUndecorated(true);
		
		pswSenha = new JPasswordField();
		pswSenha.setBorder(null);
		pswSenha.setBounds(81, 402, 243, 23);
		panel.add(pswSenha);
		
		txtUsername = new JTextField();
		txtUsername.setBorder(null);
		txtUsername.setBounds(81, 293, 243, 23);
		panel.add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(LoginAdmin.class.getResource("/img/LoginAdmin.png")));
		lblNewLabel.setBounds(0, 0, 384, 556);
		panel.add(lblNewLabel);
		
	}
	private void login() {
        String username = txtUsername.getText();
        String password = new String(pswSenha.getPassword());

        try (Connection conexao = ConnectionFactory.createConnection()) {
            String sql = "SELECT cargo, senha FROM funcionarios WHERE username = ?";
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String cargo = rs.getString("cargo");
                String storedPassword = rs.getString("senha");

                // Verifica se o cargo é Admin
                if ("Admin".equalsIgnoreCase(cargo)) {
                    // Verifica a senha
                    if (BCryptUtil.checkPassword(password, storedPassword)) {
                        JOptionPane.showMessageDialog(this, "Login bem-sucedido!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                        // Aqui você pode abrir a próxima tela ou realizar outras ações
                        
                        new Admin().setVisible(true); //Abre a janela Admin
                    } else {
                        JOptionPane.showMessageDialog(this, "Senha incorreta.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Acesso negado. Somente administradores podem logar.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Usuário não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

}

