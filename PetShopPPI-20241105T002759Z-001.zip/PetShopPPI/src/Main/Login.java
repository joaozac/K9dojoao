
package Main;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BCrypts.BCrypt;
import JDBC.ConnectionFactory;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;


import javax.swing.DebugGraphics;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Login extends JFrame {
	public static int xMouse, yMouse;

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField pswSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 595);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false); // Desativa o redimensionamento da janela

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//-------------- Close Button --------------	--------------	--------------	
		JPanel panelBarra = new JPanel();
		panelBarra.setBounds(0, 0, 400, 34);
		panelBarra.setBackground(new Color(36, 121, 188));
		contentPane.add(panelBarra);
		panelBarra.setLayout(null);
		
		JLabel lblMinimiWin = new JLabel("");
		lblMinimiWin.setIcon(new ImageIcon(Login.class.getResource("/img/minus.png")));
		lblMinimiWin.setFocusable(false);
		lblMinimiWin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setState(ICONIFIED);
			}	
		});
		lblMinimiWin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblMinimiWin.setHorizontalAlignment(SwingConstants.CENTER);
		lblMinimiWin.setForeground(Color.WHITE);
		lblMinimiWin.setToolTipText("");
		lblMinimiWin.setLabelFor(panelBarra);
		lblMinimiWin.setBounds(333, 0, 30, 34);
		panelBarra.add(lblMinimiWin);		
		//-------------- Minimize Bar --------------	--------------	--------------			
		JLabel lblCloseWin = new JLabel("");
		lblCloseWin.setBorder(null);
		lblCloseWin.setVerifyInputWhenFocusTarget(false);
		lblCloseWin.setFocusTraversalKeysEnabled(false);
		lblCloseWin.setRequestFocusEnabled(false);
		lblCloseWin.setInheritsPopupMenu(false);
		lblCloseWin.setFocusable(false);
		lblCloseWin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
				dispose();
			}		
		});	
		lblCloseWin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblCloseWin.setIcon(new ImageIcon(Login.class.getResource("/img/closes.png")));
		lblCloseWin.setToolTipText("");
		lblCloseWin.setHorizontalAlignment(SwingConstants.CENTER);
		lblCloseWin.setForeground(Color.WHITE);
		lblCloseWin.setBounds(363, 0, 27, 34);
		panelBarra.add(lblCloseWin);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(95, 366, 209, 20);
		contentPane.add(txtUsername);
		txtUsername.setFont(new Font("Arial Black", Font.PLAIN, 11));
		txtUsername.setBackground(new Color(192, 192, 192));
		txtUsername.setBorder(null);
		txtUsername.setColumns(10);
		
		JButton btnLogin = new JButton("");
		btnLogin.setContentAreaFilled(false);
		btnLogin.setBounds(139, 499, 120, 43);
		contentPane.add(btnLogin);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login();
				
				
				//MainPage mainpage = new MainPage();
				//mainpage.setVisible(true);
				//dispose();  
				
			}
		});
		
		
		btnLogin.setFocusable(false);
		btnLogin.setBorderPainted(false);
		btnLogin.setDefaultCapable(false);
		btnLogin.setFocusPainted(false);
		btnLogin.setFocusTraversalKeysEnabled(false);
		btnLogin.setDebugGraphicsOptions(DebugGraphics.NONE_OPTION);
		btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLogin.setBorder(null);
		btnLogin.setForeground(Color.BLACK);
		btnLogin.setBackground(new Color(240, 240, 240));
		
		//-------------- Move Bar --------------	--------------	--------------			
		
		JLabel lblMoveWin = new JLabel("");
		lblMoveWin.setBounds(0, 0, 341, 34);
		contentPane.add(lblMoveWin);
		

		
		pswSenha = new JPasswordField();
		pswSenha.setBorder(null);
		pswSenha.setBackground(new Color(192, 192, 192));
		pswSenha.setBounds(95, 447, 209, 20);
		contentPane.add(pswSenha);
		lblMoveWin.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x, y;
				x = e.getXOnScreen();
				y = e.getYOnScreen();
				setLocation(x - xMouse, y - yMouse);
			}
		});
		
		lblMoveWin.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				xMouse = e.getX();
				yMouse = e.getX();
			}
		});
		

		JLabel lblFundo = new JLabel("");
		lblFundo.setIcon(new ImageIcon(Login.class.getResource("/img/LoginGui.png")));
		lblFundo.setBounds(0, 0, 400, 595);
		contentPane.add(lblFundo);

		
		
		
		//lblCloseWin.setFocusable(false);
		
		//button.setFocusable(false);
		
		setUndecorated(true);
	}
	//ao clicar no botão vai ser chamado esta ação
	private void login() {
		String username = txtUsername.getText();
		String password = new String(pswSenha.getPassword());
		
		if(authenticateUser(username, password)) {
			JOptionPane.showMessageDialog(this, "Bem-vindo " + username + "!");
			//Redirecionar para outra tela
			new MainPage().setVisible(true); //Abre a janela MainPage
			this.dispose(); //Fecha a janela de login
		}else {
			JOptionPane.showMessageDialog(this, "Usuário inválido e/ou senha incorreta!");
		}		
	}
	
	//Método para autenticar o usuário
	private boolean authenticateUser(String username, String senha) {
		boolean isValid = false;
			
		try {
			Connection conexao = ConnectionFactory.createConnection();
			
			String sql = "select senha from funcionarios where username = ?";
			PreparedStatement cmd = conexao.prepareStatement(sql);					
			cmd.setString(1, username);
			
			ResultSet resultado = cmd.executeQuery();
			
			if(resultado.next()) {
				String hashedPassword = resultado.getString("senha");
				if(BCrypt.checkpw(senha, hashedPassword)) {
					isValid = true;
				}
			}	
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isValid;
		
	}
}
