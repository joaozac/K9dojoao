package Main;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import JDBC.ConnectionFactory;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class Admin extends JFrame {
    private JTextField txtSearch;
    private JTable tblUsers;
    private DefaultTableModel model;
    private JButton btnEditarFuncionario, btnExcluirFuncionario, btnCadastrarFuncionario;
    private JButton btnNewButton;

    public Admin() {
        setTitle("Lista de Usuários");
        setSize(1080, 720);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false); // Desativa o redimensionamento da janela
        
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 1064, 681);
        
        model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Nome de Usuário");
        model.addColumn("Nome Completo");
        model.addColumn("Status");
        model.addColumn("Cargo");
        
        
        tblUsers = new JTable(model);
        tblUsers.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        TableColumnModel columnModel = tblUsers.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(50);  // ID
        columnModel.getColumn(1).setPreferredWidth(150); // Nome de Usuário
        columnModel.getColumn(2).setPreferredWidth(200); // Nome Completo
        columnModel.getColumn(3).setPreferredWidth(100); // Status
        columnModel.getColumn(4).setPreferredWidth(100); // Cargo
        
        JScrollPane scrollPane = new JScrollPane(tblUsers);
        scrollPane.setBounds(10, 125, 1044, 426);
        getContentPane().setLayout(null);
        panel.setLayout(null);
        panel.add(scrollPane);
        
        getContentPane().add(panel);
        

        
        btnEditarFuncionario = new JButton("");
        btnEditarFuncionario.setContentAreaFilled(false);
        btnEditarFuncionario.setFocusable(false);
        btnEditarFuncionario.setFocusTraversalKeysEnabled(false);
        btnEditarFuncionario.setFocusPainted(false);
        btnEditarFuncionario.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnEditarFuncionario.setBorderPainted(false);
        btnEditarFuncionario.setBorder(null);
        btnEditarFuncionario.setBounds(440, 580, 119, 23);
        panel.add(btnEditarFuncionario);
        
        btnExcluirFuncionario = new JButton("");
        btnExcluirFuncionario.setContentAreaFilled(false);
        btnExcluirFuncionario.setFocusable(false);
        btnExcluirFuncionario.setFocusTraversalKeysEnabled(false);
        btnExcluirFuncionario.setFocusPainted(false);
        btnExcluirFuncionario.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnExcluirFuncionario.setBorderPainted(false);
        btnExcluirFuncionario.setBorder(null);
        btnExcluirFuncionario.setBounds(678, 580, 121, 23);
        panel.add(btnExcluirFuncionario);
        
        btnCadastrarFuncionario = new JButton("");
        btnCadastrarFuncionario.setContentAreaFilled(false);
        btnCadastrarFuncionario.setFocusable(false);
        btnCadastrarFuncionario.setFocusTraversalKeysEnabled(false);
        btnCadastrarFuncionario.setFocusPainted(false);
        btnCadastrarFuncionario.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCadastrarFuncionario.setBorderPainted(false);
        btnCadastrarFuncionario.setBorder(null);
        btnCadastrarFuncionario.setBounds(193, 580, 128, 23);
        panel.add(btnCadastrarFuncionario);
        txtSearch = new JTextField(20);
        txtSearch.setEnabled(false);
        txtSearch.setBorder(null);
        txtSearch.setBounds(263, 65, 119, 23);
        panel.add(txtSearch);
        JButton btnSearch = new JButton("");
        btnSearch.setEnabled(false);
        btnSearch.setContentAreaFilled(false);
        btnSearch.setFocusable(false);
        btnSearch.setFocusTraversalKeysEnabled(false);
        btnSearch.setFocusPainted(false);
        btnSearch.setDefaultCapable(false);
        btnSearch.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnSearch.setBorderPainted(false);
        btnSearch.setBorder(null);
        btnSearch.setBounds(453, 62, 134, 29);
        panel.add(btnSearch);
        
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = txtSearch.getText();
                searchUsers(keyword);
            }
        });
        btnCadastrarFuncionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CadastrarFuncionario().setVisible(true); // Passa a instância atual de UsuList
            }
        });
        btnExcluirFuncionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteUser();
            }
        });
        btnEditarFuncionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editUser();
            }
        });
        loadAllUsers();
        

        
        btnNewButton = new JButton("");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		loadAllUsers();
        	}
        });
        btnNewButton.setIcon(new ImageIcon(Admin.class.getResource("/img/refresh-17x17.png")));
        btnNewButton.setBorder(null);
        btnNewButton.setBorderPainted(false);
        btnNewButton.setContentAreaFilled(false);
        btnNewButton.setBounds(965, 91, 89, 23);
        panel.add(btnNewButton);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(Admin.class.getResource("/img/walladmin.png")));
        lblNewLabel.setBounds(0, 0, 1064, 681);
        panel.add(lblNewLabel);
    }
    

    public void loadAllUsers() {
        try {
            Connection conexao = ConnectionFactory.createConnection();
            String sql = "SELECT id, username, nome, status, cargo FROM funcionarios";
            PreparedStatement pst = conexao.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            model.setRowCount(0); // Limpa os dados da tabela antes de carregar novamente
            while (rs.next()) {
                Vector<String> user = new Vector<>();
                user.add(rs.getString("id"));
                user.add(rs.getString("username"));
                user.add(rs.getString("nome"));
                user.add(rs.getString("status"));
                user.add(rs.getString("cargo"));
                model.addRow(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void searchUsers(String keyword) {
        try {
            Connection conexao = ConnectionFactory.createConnection();
            String sql = "SELECT id, username, nome, status, cargo FROM funcionarios WHERE username LIKE ? OR nome LIKE ?";
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setString(1, "%" + keyword + "%");
            pst.setString(2, "%" + keyword + "%");
            ResultSet rs = pst.executeQuery();

            model.setRowCount(0); // Limpa os dados da tabela antes de carregar novamente
            while (rs.next()) {
                Vector<String> user = new Vector<>();
                user.add(rs.getString("id"));
                user.add(rs.getString("username"));
                user.add(rs.getString("nome"));
                user.add(rs.getString("status"));
                user.add(rs.getString("cargos"));
                model.addRow(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void editUser() {
        int selectRow = tblUsers.getSelectedRow();
        if (selectRow >= 0) {
            String userId = model.getValueAt(selectRow, 0).toString();
            new EditarFuncionario(userId, null).setVisible(true); // Passa a instância de UsuList
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um Funcionário para editar.");
        }
    }

    private void deleteUser() {
        int selectRow = tblUsers.getSelectedRow();
        if (selectRow >= 0) {
            String userId = model.getValueAt(selectRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja excluir este funcionário?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    Connection conexao = ConnectionFactory.createConnection();
                    String sql = "DELETE FROM funcionarios WHERE id = ?";
                    PreparedStatement pst = conexao.prepareStatement(sql);
                    pst.setString(1, userId);
                    pst.executeUpdate();
                    loadAllUsers(); // Atualizar a tabela
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um Usuário para excluir.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Admin().setVisible(true);
        });
    }
}
