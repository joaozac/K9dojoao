package Main;

import javax.swing.*;
import JDBC.ConnectionFactory;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ExcluirFuncionario extends JFrame {
    private JTextField txtId;

    public ExcluirFuncionario() {
        setTitle("Excluir Funcionário");
        setBounds(100, 100, 280, 115);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel label = new JLabel("ID do Funcionário:");
        label.setBounds(0, 0, 284, 47);
        contentPane.add(label);
        txtId = new JTextField();
        txtId.setBounds(98, 13, 149, 20);
        contentPane.add(txtId);

        JButton btnDelete = new JButton("Excluir");
        btnDelete.setBounds(98, 44, 149, 20);
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteFuncionario();
            }
        });
        contentPane.add(btnDelete);
    }

    private void deleteFuncionario() {
        int confirm = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir este funcionário?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conexao = ConnectionFactory.createConnection()) {
                String sql = "DELETE FROM funcionarios WHERE id = ?";
                try (PreparedStatement pst = conexao.prepareStatement(sql)) {
                    pst.setInt(1, Integer.parseInt(txtId.getText()));
                    int rowsAffected = pst.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(this, "Funcionário excluído com sucesso!");
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this, "Funcionário não encontrado.");
                    }
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir funcionário: " + e.getMessage());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID inválido.");
            }
        }
    }
    
 // Conectar ao Banco de Dados
    private Connection conectarBanco() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/projetointegradorpetshop";
        String user = "root";
        String password = "";
        return DriverManager.getConnection(url, user, password);
    }
}
