package BCrypts;
import java.security.SecureRandom;

public class BCryptUtil {
	private static final int WORKLOAD = 12;

    // Método para gerar um hash seguro a partir de uma senha
    public static String hashPassword(String plainTextPassword) {
        String salt = BCrypt.gensalt(WORKLOAD, new SecureRandom());
        return BCrypt.hashpw(plainTextPassword, salt);
    }

    // Método para verificar uma senha em texto plano com um hash armazenado
    public static boolean checkPassword(String plainTextPassword, String storedHash) {
        if (storedHash == null || !storedHash.startsWith("$2a$")) {
            throw new IllegalArgumentException("Hash inválido");
        }
        return BCrypt.checkpw(plainTextPassword, storedHash);
    }

    // Exemplo de uso durante o cadastro
    public static void main(String[] args) {
        // Cadastro de usuário - criando o hash da senha
        String senha = "senhaSegura123";
        String hash = hashPassword(senha);
        System.out.println("Hash gerado para a senha: " + hash);

        // Verificação durante o login
        String senhaTentativa = "senhaSegura123";
        boolean senhaCorreta = checkPassword(senhaTentativa, hash);
        System.out.println("Senha está correta? " + senhaCorreta);
    }
}
