package JDBC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	
	    private static final String URL = "jdbc:mysql://localhost:3306/projetointegradorpetshop"; // URL do driver JDBC
	    private static final String USER = "root"; // Usuário do banco de dados
	    private static final String PASSWORD = ""; // Senha do banco de dados

	    // Método para criar uma conexão com o banco de dados
	    public static Connection createConnection() throws SQLException {
	        return DriverManager.getConnection(URL, USER, PASSWORD);
	    }

	    // Método principal para testar a conexão (opcional)
	    public static void main(String[] args) {
	        try (Connection connection = createConnection()) { // Uso do try-with-resources para fechar automaticamente a conexão
	            if (connection != null) {
	                System.out.println("Conexão estabelecida com sucesso!");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}
